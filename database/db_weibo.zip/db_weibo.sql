/*
SQLyog Job Agent v12.09 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.38 : Database - db_weibo
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_weibo` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_weibo`;

/*Table structure for table `zc_at` */

DROP TABLE IF EXISTS `zc_at`;

CREATE TABLE `zc_at` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(8) NOT NULL COMMENT '用户id',
  `friend_id` int(8) NOT NULL COMMENT '好友id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否@:0未@;1已@',
  `addtime` char(8) NOT NULL COMMENT '关注时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `zc_at` */

/*Table structure for table `zc_collect` */

DROP TABLE IF EXISTS `zc_collect`;

CREATE TABLE `zc_collect` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(8) NOT NULL COMMENT '用户id',
  `post_id` int(8) NOT NULL COMMENT '收藏微博id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否收藏:0否;1是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `zc_collect` */

/*Table structure for table `zc_friends` */

DROP TABLE IF EXISTS `zc_friends`;

CREATE TABLE `zc_friends` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(8) NOT NULL COMMENT '用户id',
  `friend_id` int(8) NOT NULL COMMENT '好友id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否关注:0未关注;1已关注',
  `addtime` char(8) NOT NULL COMMENT '关注时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `zc_friends` */

/*Table structure for table `zc_post` */

DROP TABLE IF EXISTS `zc_post`;

CREATE TABLE `zc_post` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `content` text NOT NULL COMMENT '微博内容',
  `addtime` varchar(50) NOT NULL COMMENT '发布时间',
  `username` varchar(200) NOT NULL COMMENT '用户名',
  `user_id` int(8) NOT NULL COMMENT '用户id',
  `pid` int(8) NOT NULL DEFAULT '0' COMMENT '父id',
  `post_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '微博标识:0发布;1评论;2转发',
  `parent_user_id` int(8) NOT NULL DEFAULT '0' COMMENT '回复人的id',
  `pictures` text NOT NULL COMMENT '微博图片',
  `forward_num` int(8) NOT NULL DEFAULT '0' COMMENT '转发数量',
  `comment_num` int(8) NOT NULL DEFAULT '0' COMMENT '评论数',
  `praise_num` int(8) NOT NULL DEFAULT '0' COMMENT '点赞数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `zc_post` */

/*Table structure for table `zc_praise` */

DROP TABLE IF EXISTS `zc_praise`;

CREATE TABLE `zc_praise` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(8) NOT NULL COMMENT '用户id',
  `post_id` int(8) NOT NULL COMMENT '收藏微博id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `zc_praise` */

/*Table structure for table `zc_user` */

DROP TABLE IF EXISTS `zc_user`;

CREATE TABLE `zc_user` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(50) NOT NULL COMMENT '密码',
  `addtime` char(10) NOT NULL COMMENT '注册时间',
  `sex` tinyint(1) DEFAULT '0' COMMENT '性别：0保密；1男，2女',
  `qq` varchar(50) DEFAULT NULL COMMENT 'qq号',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `posts_num` int(8) DEFAULT '0' COMMENT '发微博数量',
  `follows_num` int(8) DEFAULT '0' COMMENT '关注数量',
  `fans_num` int(8) DEFAULT '0' COMMENT '粉丝数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `zc_user` */

insert  into `zc_user` values (1,'admin','e10adc3949ba59abbe56e057f20f883e','1528940233',0,NULL,NULL,NULL,0,0,0),(2,'znlccy','e10adc3949ba59abbe56e057f20f883e','1528941550',1,'756311868','756311868@qq.com',NULL,6,3,8),(3,'stone','55587a910882016321201e6ebbc9f595','1529049932',0,NULL,NULL,NULL,0,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
